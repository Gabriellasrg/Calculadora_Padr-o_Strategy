/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package strategy;

/**
 *
 * @author Gabriella Rodrigues
 */
//
public class Calculando {
    public Strategy getEscolha(int escolha){
        
        if (escolha == 1){
            return new Soma();
            
        }
        else if (escolha == 2){
            return new Subtracao();
        }
        else if (escolha == 3){
            return new Divisao();
    }
        else if (escolha == 4){
            return new Multiplicacao();
        }
        else {
            return null;
      
        }
    }  

    }

