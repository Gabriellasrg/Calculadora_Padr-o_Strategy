/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package strategy;

/**
 *
 * @author Gabriella Rodrigues
 */

public interface Strategy {
   
    public double calcular(double valor1, double valor2 );
}
