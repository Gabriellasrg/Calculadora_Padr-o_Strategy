/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package strategy;


import javax.swing.JOptionPane;

/**
 *
 * @author Gabriella Rodrigues
 */

//Recebe os valores e executa
public class Main {

  

  

 
    public static void main(String[] args){
        
        Calculando calculando = new Calculando();
       
        
      int escolha = Integer.parseInt(JOptionPane.showInputDialog("1 - Soma. \n 2 - Subtração. \n 3 - Divisão. \n 4 - Multiplicação."));
      
      double valor1 = Double.parseDouble(JOptionPane.showInputDialog("Digite o primeiro valor: "));
      
      double valor2 = Double.parseDouble(JOptionPane.showInputDialog("Digite o segundo valor: "));
    
     double resultado = calculando.getEscolha(escolha).calcular(valor1, valor2);
     JOptionPane.showMessageDialog(null, "O resultado é: " + resultado);
        
      
      
    }
        }
        
    
